// Used for detecting if ad blockers are enabled
var e=document.createElement('div');
e.id='sklocalscriptbait';
e.style.display='none';
document.body.appendChild(e);
