'use strict';

setOffCanvasAdDivDimensions = true;
